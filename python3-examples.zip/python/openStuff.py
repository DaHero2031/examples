#Xabrir = open("openme.txt", "r")

#print(Xabrir.readable())

##print(Xabrir.readlines())

#print(Xabrir.readline())

#print(Xabrir.read())

#Xabrir.close()

'''
xescrib = open("openme.txt", "a")

xescrib.write("\nRobin, ¿que haces papa?")

xescrib.close()
'''

xsobreescrib = open("openme.txt","w")

xsobreescrib.write("\nRicky fort es lo mas")

xsobreescrib.close()
