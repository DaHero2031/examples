def cube(num):
	cubed = num*num*num
	print("done")
	return cubed
print(cube(2))
