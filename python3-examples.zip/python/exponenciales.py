def exponenciar(base, exponente):
	resultado = 1
	for indice in range(exponente):
		resultado = resultado * base
	return resultado

print(exponenciar(2, 3))
