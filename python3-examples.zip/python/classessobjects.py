class student:
	
	def __init__(self, name, carrera, promedio, on_probation):
		self.name = name
		self.carrera = carrera
		self.promedio = promedio
		self.is_on_probation = on_probation
	
	def honrado(self):
		if self.promedio >= 8:
			return True
		else:
			return False
		
class auto:
	
	def __init__(self, ruedas, velMax, consumo):
		self.ruedas = ruedas
		self.velMax = velMax
		self.consumo = consumo
		
class phone:

	def __init__(self, llam, msj, alar, pant):
		self.llam = llam
		self.msj = msj
		self.alar = alar
		self.pant = pant
