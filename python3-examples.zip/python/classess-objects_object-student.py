from classessobjects import student
from classessobjects import auto
from classessobjects import phone

class camioneta(auto):
	def arrancar(self):
		print("vrrum")
print("________________________________________________________________")
camioneta1 = camioneta(6, 200, 15)
camioneta1.arrancar()
print(camioneta1.ruedas+camioneta1.velMax)
print("________________________________________________________________")

Student1 = student("Jimmy", "Administracion", 7.5, False)
print(Student1.promedio)
print("tiene honores "+str(Student1.honrado()))
Student2 = student("Violeta", "Turismo", 9.0, False)
print(Student2.promedio)
print("tiene honores "+str(Student2.honrado()))
print("________________________________________________________________")
try:
	auto1 = auto(4, 300, 10)
	print(str(auto1.ruedas)+" ruedas")
	print(str(auto1.velMax)+" Km/h")
except NameError as err:
	print(err)
print("________________________________________________________________")
phoneSamsung = phone( "RING!", "purim!", "CUACK..CUACK..CUACK!", "click")
print(phoneSamsung.msj)
print(phoneSamsung.llam)
print(phoneSamsung.pant)
