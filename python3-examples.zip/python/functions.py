def saluda(name, age):
	print("Hola "+name+" tenes "+str(age))

print("top")
saluda("Hayla", 19)
print("bottom")
