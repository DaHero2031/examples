timbre = False
persona = False
if timbre and persona:
	print("RING!")
elif persona and not(timbre):
	print("timbre descompuesto")
elif timbre and not(persona):
	print("un fantasma toca el timbre")
else:
	print("no hay nadie ahi")
	
num1 = input("a")	
num2 = input("b")
num3 = input("c")
def max_num(num1, num2, num3):
	if num1 >= num2 and num1 >= num3:
		return num1
	elif num2 >= num1 and num2>= num3:
		return num2
	else:
		return num3
