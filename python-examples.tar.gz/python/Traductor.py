def traducirAInutil(palabra):
	traduccion = ""
	for letra in palabra:
		if letra in "AEIOUaeiou":
			traduccion = traduccion + "g"
		else:
			traduccion = traduccion + letra
	return traduccion
print(traducirAInutil(input(": ")))
