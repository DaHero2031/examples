try:
	errorGen = 1/0
	numero = int(input("dame un numero: "))
	print(numero)
except ValueError:
	print("dije un numero...")
except ZeroDivisionError as err:
	print(err)
