palabra = "humano"
intento = ""
vidas = 3
print("¿Cual es el animal que camina en cuatro patas a la mañana, en dos al atardecer y en tres al caer la noche?")
print("-------------------------------------------------------------")
while intento != palabra and vidas > 0:
	print("tenes "+str(vidas)+" vidas")
	intento = input("==> ")
	print("")
	vidas = vidas - 1
if intento == palabra:
	print("¡Ganaste!")
elif vidas == 0:
	print("¡Perdiste!")
