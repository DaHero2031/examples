red_numeral = [
	[1,2,3],
	[4,5,6],
	[7,8,9],
	[0]
]

for x in red_numeral:
	for y in x:
		print(y)
