name = input("enter your name: ")
age = input("enter your age: ")
phrase = "Hola!"
is_male = True
print("este es "+name+"\n"+name+" tiene "+str(age)+" años")
print("a "+name+" le encanta gedit")
print("porque es muy versatil")
print(name+" puede editar texto")
print("y "+name+" puede programar!")
print(name+" tiene un triangulo")
print("  /|")
print(" / |")
print("/__|")
phrase = "HOLA"
print(name+": \""+phrase.lower()+" que tal?\"")
print(len(phrase))
print(phrase[0]+phrase[3])
print(phrase.index("L"))
print(phrase.replace("HOLA", "CHAU"))
