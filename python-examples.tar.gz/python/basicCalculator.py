num1 = float(input("primer numero:	"))
oper = input("operacion:	")
num2 = float(input("segundo numero:	"))

if oper == "+":
	print(num1+num2)
elif oper == "-":
	print(num1-num2)
elif oper == "/":
	print(num1/num2)
elif oper == "*":
	print(num1*num2)
else:
	print("¡operacion invalida!")
