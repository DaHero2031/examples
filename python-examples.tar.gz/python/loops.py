i = 1
while i <= 10:
	print(i)
	i = i + 1
print("finish")

for i in "Haloha!":
	print(i)

array = ["Hola", "Ricardo", "Astrologo"]
for l in array:
	print(l)

for indice in range(7,10):
	print(indice)
