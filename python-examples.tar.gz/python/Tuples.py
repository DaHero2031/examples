coordinates = [(2,9) , (5,1) , (9,9)]
print(coordinates[0])
