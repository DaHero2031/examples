class student:
	
	def __init__(self, name, carrera, promedio, on_probation):
		self.name = name
		self.carrera = carrera
		self.promedio = promedio
		self.is_on_probation = on_probation
